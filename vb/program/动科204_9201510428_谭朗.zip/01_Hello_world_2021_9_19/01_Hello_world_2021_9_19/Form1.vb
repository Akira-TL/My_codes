﻿Public Class Form1
    Private Sub BtnHelloWorld_Click(sender As Object, e As EventArgs) Handles BtnHelloWorld.Click
        LblHelloworld.Text = "Hello word!"
    End Sub
End Class
