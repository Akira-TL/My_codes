﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim a As String
        'Label1.Text = Form1.
    End Sub
End Class